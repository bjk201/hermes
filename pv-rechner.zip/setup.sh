#!/bin/bash
# PV-Rechner Setup-Script
# Auf der LXC ausführen: bash setup-pv-rechner.sh

set -e

DIR="/opt/stacks/pv-rechner"
mkdir -p "$DIR/app/templates" "$DIR/app/static/css" "$DIR/app/static/js"

# ── docker-compose.yml ──────────────────────────────────────────────────────
cat > "$DIR/docker-compose.yml" << 'COMPOSE'
version: "3.9"

services:
  db:
    image: postgres:16-alpine
    container_name: pv-rechner-db
    environment:
      POSTGRES_DB: pvrechner
      POSTGRES_USER: pvuser
      POSTGRES_PASSWORD: pvpass2026
    volumes:
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U pvuser -d pvrechner"]
      interval: 10s
      timeout: 5s
      retries: 5
    restart: unless-stopped

  app:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: pv-rechner-app
    environment:
      POSTGRES_HOST: db
      POSTGRES_PORT: "5432"
      POSTGRES_DB: pvrechner
      POSTGRES_USER: pvuser
      POSTGRES_PASSWORD: pvpass2026
      APP_PASSWORD: pv2024
      SECRET_KEY: a^nGxhP9$kL2mN7qR4wZ8bY3cE6fU1j
    ports:
      - "3333:5000"
    depends_on:
      db:
        condition: service_healthy
    restart: unless-stopped

volumes:
  pgdata:
COMPOSE

# ── Dockerfile ──────────────────────────────────────────────────────────────
cat > "$DIR/Dockerfile" << 'DOCKERFILE'
FROM python:3.12-slim

WORKDIR /app

RUN apt-get update && apt-get install -y --no-install-recommends \
    libpq-dev gcc \
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY app/ ./app/

WORKDIR /app/app

EXPOSE 5000

CMD ["gunicorn", "--bind", "0.0.0.0:5000", "--workers", "2", "main:app"]
DOCKERFILE

# ── requirements.txt ────────────────────────────────────────────────────────
cat > "$DIR/requirements.txt" << 'REQS'
Flask==3.1.*
Flask-SQLAlchemy==3.1.*
SQLAlchemy==2.0.*
psycopg2-binary==2.9.*
gunicorn==23.0.*
Werkzeug==3.1.*
REQS

# ── .env.example ────────────────────────────────────────────────────────────
cat > "$DIR/.env.example" << 'ENV'
POSTGRES_DB=pvrechner
POSTGRES_USER=pvuser
POSTGRES_PASSWORD=pvpass2026
APP_PASSWORD=pv2024
SECRET_KEY=change-me
ENV

# ── .gitignore ──────────────────────────────────────────────────────────────
cat > "$DIR/.gitignore" << 'GITIGNORE'
__pycache__/
*.pyc
.env
*.egg-info/
.venv/
GITIGNORE

echo "=== Verzeichnisstruktur ==="
find "$DIR" -type f | sort
echo ""
echo "=== Fertig! ==="
echo "Verzeichnis: $DIR"
echo ""
echo "In Portainer:"
echo "  Stacks → Add Stack → Web editor"
echo "  Pfad: $DIR/docker-compose.yml"
echo "  Oder: docker compose up -d (im Verzeichnis $DIR)"
